//go:generate bash -c "go run ../internal/cmd/weave/weave.go ./go-types.md > README.md"

package gotypes
